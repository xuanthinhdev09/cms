﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'it', {
	alt: 'Testo alternativo',
	btnUpload: 'Invia al server',
	captioned: 'Immagine con didascalia',
	captionPlaceholder: 'Didascalia',
	infoTab: 'Informazioni immagine',
	lockRatio: 'Blocca rapporto',
	menu: 'Proprietà immagine',
	pathName: 'immagine',
	pathNameCaption: 'didascalia',
	resetSize: 'Reimposta dimensione',
	resizer: 'Fare clic e trascinare per ridimensionare',
	title: 'Proprietà immagine',
	uploadTab: 'Carica',
	urlMissing: 'Manca l\'URL dell\'immagine.'
} );
