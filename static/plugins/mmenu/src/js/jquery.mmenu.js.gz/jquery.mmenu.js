/*
	This file does not excist.
	If you are looking for the unminified version of jquery.mmenu.min.js,
	hava a look at the files jquery.mmenu.oncanvas.js and jquery.mmenu.offcanvas.js
*/